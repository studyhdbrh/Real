import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";

// For demonstration, we'll use a static user ID until we implement authentication
const DEMO_USER_ID = 1;

// Profile form schema
const profileFormSchema = z.object({
  display_name: z.string().min(2, { message: "Display name must be at least 2 characters" }).max(100),
  school: z.string().max(100).optional(),
  major: z.string().max(100).optional(),
  bio: z.string().max(500).optional(),
  study_goal: z.string().max(500).optional(),
  avatar_url: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal("")),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

export default function Profile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [profileId, setProfileId] = useState<number | null>(null);

  // Fetch user data
  const { data: userData, isLoading: isUserLoading } = useQuery({
    queryKey: ["/api/users", DEMO_USER_ID],
    queryFn: async () => {
      return apiRequest(`/api/users/${DEMO_USER_ID}`);
    },
  });

  // Fetch profile data
  const { data: profileData, isLoading: isProfileLoading } = useQuery({
    queryKey: ["/api/profiles", DEMO_USER_ID],
    queryFn: async () => {
      return apiRequest(`/api/profiles/${DEMO_USER_ID}`);
    },
    onSuccess: (data) => {
      if (data && data.id) {
        setProfileId(data.id);
      }
    },
    onError: () => {
      // If profile doesn't exist, we'll create a new one
      setProfileId(null);
    },
  });

  // Create profile mutation
  const createProfile = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      const profileData = {
        ...data,
        user_id: DEMO_USER_ID,
      };
      return apiRequest("/api/profiles", {
        method: "POST",
        body: JSON.stringify(profileData),
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles", DEMO_USER_ID] });
      setProfileId(data.id);
      toast({
        title: "Profile created!",
        description: "Your profile has been successfully created.",
      });
    },
  });

  // Update profile mutation
  const updateProfile = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      if (!profileId) return null;
      return apiRequest(`/api/profiles/${profileId}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles", DEMO_USER_ID] });
      toast({
        title: "Profile updated!",
        description: "Your profile has been successfully updated.",
      });
    },
  });

  // Form setup
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      display_name: "",
      school: "",
      major: "",
      bio: "",
      study_goal: "",
      avatar_url: "",
    },
  });

  // Update form with profile data when it loads
  useEffect(() => {
    if (profileData) {
      form.reset({
        display_name: profileData.display_name || "",
        school: profileData.school || "",
        major: profileData.major || "",
        bio: profileData.bio || "",
        study_goal: profileData.study_goal || "",
        avatar_url: profileData.avatar_url || "",
      });
    }
  }, [profileData, form]);

  // Form submission handler
  function onSubmit(data: ProfileFormValues) {
    if (profileId) {
      updateProfile.mutate(data);
    } else {
      createProfile.mutate(data);
    }
  }

  const isLoading = isUserLoading || isProfileLoading;
  const isPending = createProfile.isPending || updateProfile.isPending;

  return (
    <div className="container max-w-4xl py-10">
      <h1 className="text-3xl font-bold mb-8">My Profile</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Card */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Profile</CardTitle>
            <CardDescription>Your public profile information</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            {isLoading ? (
              <Skeleton className="h-24 w-24 rounded-full" />
            ) : (
              <Avatar className="h-24 w-24">
                <AvatarImage src={profileData?.avatar_url || ""} />
                <AvatarFallback>
                  {(profileData?.display_name || userData?.username || "User")
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
            )}
            
            <div className="mt-4 text-center">
              {isLoading ? (
                <>
                  <Skeleton className="h-6 w-32 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </>
              ) : (
                <>
                  <h2 className="text-xl font-bold">
                    {profileData?.display_name || userData?.username || "New User"}
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    {profileData?.school ? `${profileData.school}` : "No school set"}
                    {profileData?.major ? ` • ${profileData.major}` : ""}
                  </p>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Edit Form */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Edit Profile</CardTitle>
            <CardDescription>Update your profile information</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="display_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Your name" {...field} />
                      </FormControl>
                      <FormDescription>
                        This is how your name will appear to others.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="school"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>School</FormLabel>
                        <FormControl>
                          <Input placeholder="Your school" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="major"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Major/Subject</FormLabel>
                        <FormControl>
                          <Input placeholder="Your major or subject" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us a bit about yourself" 
                          className="resize-none" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="study_goal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Study Goal</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="What are you working towards?" 
                          className="resize-none" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="avatar_url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Avatar URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://example.com/avatar.jpg" {...field} />
                      </FormControl>
                      <FormDescription>
                        Enter a URL to an image to use as your avatar.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" disabled={isPending}>
                  {isPending ? "Saving..." : "Save Changes"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}