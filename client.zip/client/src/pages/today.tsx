import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Umbrella, FastForward, Link } from 'lucide-react';
import { HolidayModal } from '@/components/holiday-modal';
import { Badge } from '@/components/ui/badge';
import { TaskItem } from '@/components/task-item';
import { useTasks } from '@/hooks/use-tasks';
import { useHolidays } from '@/hooks/use-holidays';
import { getSettings } from '@/lib/storage';
import { useLocation } from 'wouter';

export default function Today() {
  const [showHolidayModal, setShowHolidayModal] = useState(false);
  const [_, navigate] = useLocation();
  
  const {
    getTodayTasks,
    moveToBacklog,
    completeTask,
    getTaskStats,
    workAhead
  } = useTasks();
  
  const {
    holidays,
    addHoliday,
    removeHoliday,
    getRemainingHolidays,
    isHoliday
  } = useHolidays();
  
  const todayTasks = getTodayTasks();
  const stats = getTaskStats();
  const settings = getSettings();
  const remainingHolidays = getRemainingHolidays(settings.monthlyHolidays);
  
  // Check if today is a holiday
  const today = new Date().toISOString().split('T')[0];
  const isTodayHoliday = isHoliday(today);

  // Take leave (move all uncompleted tasks to backlog)
  const handleTakeLeave = () => {
    todayTasks
      .filter(task => !task.completed)
      .forEach(task => moveToBacklog(task.id));
  };

  // Get tomorrow's first task for work ahead feature
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowISODate = tomorrow.toISOString().split('T')[0];
  
  const tomorrowTasks = useTasks().tasks.filter(
    task => task.scheduledDate === tomorrowISODate && !task.completed && !task.isBacklog
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="flex items-center space-x-3">
          <Badge 
            variant="secondary" 
            className="bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 py-1 px-3 rounded-full text-sm font-medium"
          >
            {remainingHolidays} holidays remaining this month
          </Badge>
          <Button
            variant="link"
            className="text-amber-500 hover:text-amber-600 text-sm font-medium flex items-center p-0"
            onClick={() => setShowHolidayModal(true)}
          >
            <Umbrella className="h-4 w-4 mr-1" />
            Manage Holidays
          </Button>
        </div>
        <div className="mt-3 md:mt-0 flex space-x-3">
          <Button
            variant="outline"
            className="border-red-300 text-red-700 dark:border-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
            onClick={handleTakeLeave}
          >
            <Umbrella className="h-4 w-4 mr-1" />
            Take Leave
          </Button>
          {tomorrowTasks.length > 0 && (
            <Button
              variant="outline"
              className="border-emerald-300 text-emerald-700 dark:border-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
              onClick={() => workAhead(tomorrowTasks[0].id)}
            >
              <FastForward className="h-4 w-4 mr-1" />
              Work Ahead
            </Button>
          )}
        </div>
      </div>

      {/* Tasks summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Today's Progress</h3>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300">
                {stats.today.completed}/{stats.today.total} Complete
              </Badge>
            </div>
            <div className="mt-2 h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div 
                className="bg-emerald-500 h-full rounded-full" 
                style={{ width: `${stats.today.percentage}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Weekly Completion</h3>
              <Badge variant="secondary" className="bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300">
                {stats.week.percentage}%
              </Badge>
            </div>
            <div className="mt-2 h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div 
                className="bg-indigo-500 h-full rounded-full" 
                style={{ width: `${stats.week.percentage}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Backlog Tasks</h3>
              <Badge variant="secondary" className="bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">
                {stats.backlog.pending} Pending
              </Badge>
            </div>
            <div className="mt-2 flex justify-end">
              <Button 
                variant="link" 
                className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 p-0"
                onClick={() => navigate('/backlog')}
              >
                View Backlog
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Task List */}
      <Card>
        <div className="border-b dark:border-slate-700 px-6 py-4">
          <h2 className="text-xl font-semibold">Today's Tasks</h2>
        </div>
        
        <div className="divide-y dark:divide-slate-700">
          {todayTasks.length === 0 ? (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500 dark:text-gray-400">No tasks scheduled for today.</p>
              {isTodayHoliday && (
                <p className="text-indigo-500 dark:text-indigo-400 mt-2">Today is a holiday! Enjoy your day off.</p>
              )}
              <Button 
                variant="link"
                className="mt-4"
                onClick={() => navigate('/week')}
              >
                Add tasks to your plan
              </Button>
            </div>
          ) : (
            todayTasks.map(task => (
              <TaskItem 
                key={task.id}
                task={task}
                onComplete={completeTask}
              />
            ))
          )}
        </div>
        
        {todayTasks.length > 0 && (
          <div className="px-6 py-4 bg-gray-50 dark:bg-slate-800 border-t dark:border-slate-700">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                Updated {new Date().toLocaleTimeString()}
              </span>
              <Button
                variant="link"
                className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 p-0"
                onClick={() => todayTasks.forEach(task => !task.completed && completeTask(task.id))}
              >
                Complete All
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* Holiday Modal */}
      <HolidayModal
        isOpen={showHolidayModal}
        onClose={() => setShowHolidayModal(false)}
        holidays={holidays}
        remainingHolidays={remainingHolidays}
        monthlyAllowance={settings.monthlyHolidays}
        onAddHoliday={addHoliday}
        onRemoveHoliday={removeHoliday}
      />
    </div>
  );
}
