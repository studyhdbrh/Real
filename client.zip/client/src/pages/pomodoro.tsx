import React, { useEffect } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Pause, RefreshCw, Coffee, Brain } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { usePomodoro } from '@/hooks/use-pomodoro';
import { getSettings } from '@/lib/storage';
import { formatTime } from '@/lib/utils';
import { requestNotificationPermission } from '@/lib/utils';

export default function Pomodoro() {
  const settings = getSettings();
  const { 
    isRunning, 
    isPaused, 
    mode, 
    timeLeft, 
    progress, 
    startTimer, 
    pauseTimer, 
    resumeTimer, 
    resetTimer, 
    switchMode,
    getSessionsByTask
  } = usePomodoro(settings.focusDuration, settings.breakDuration);

  // Request notification permission on component mount
  useEffect(() => {
    requestNotificationPermission();
  }, []);

  // Get recent sessions grouped by task
  const sessionsByTask = getSessionsByTask().slice(0, 3);

  return (
    <div className="space-y-6">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader className="border-b dark:border-slate-700 px-6 py-4">
            <CardTitle className="text-xl font-semibold">Pomodoro Timer</CardTitle>
          </CardHeader>
          
          <CardContent className="p-6 flex flex-col items-center">
            <div className="mb-8 text-center">
              <h3 className="text-2xl font-semibold mb-2">
                {mode === 'focus' ? 'Focus Time' : 'Break Time'}
              </h3>
              <p className="text-gray-500 dark:text-gray-400">
                {mode === 'focus' ? 'Stay focused on your task' : 'Take a short break'}
              </p>
            </div>
            
            <div className="relative w-64 h-64 mb-8">
              {/* Timer circle */}
              <div className="absolute inset-0 rounded-full bg-gray-100 dark:bg-slate-800"></div>
              <div className="absolute inset-0 rounded-full overflow-hidden">
                <div className="absolute inset-0 origin-center transform -rotate-90">
                  <div 
                    className={`absolute top-0 bottom-0 left-0 transition-all duration-1000 ${
                      mode === 'focus' ? 'bg-indigo-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${progress}%` }}
                  >
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span 
                  className={`text-5xl font-bold ${
                    mode === 'focus' ? 'text-indigo-600 dark:text-indigo-400' : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  {formatTime(timeLeft)}
                </span>
              </div>
            </div>
            
            <div className="flex space-x-4">
              {!isRunning ? (
                <Button onClick={startTimer}>
                  <Play className="h-4 w-4 mr-1" />
                  Start
                </Button>
              ) : !isPaused ? (
                <Button variant="warning" onClick={pauseTimer}>
                  <Pause className="h-4 w-4 mr-1" />
                  Pause
                </Button>
              ) : (
                <Button onClick={resumeTimer}>
                  <Play className="h-4 w-4 mr-1" />
                  Resume
                </Button>
              )}
              
              <Button variant="outline" onClick={resetTimer}>
                <RefreshCw className="h-4 w-4 mr-1" />
                Reset
              </Button>
              
              <Button variant="outline" onClick={switchMode}>
                {mode === 'focus' ? (
                  <>
                    <Coffee className="h-4 w-4 mr-1" />
                    Switch to Break
                  </>
                ) : (
                  <>
                    <Brain className="h-4 w-4 mr-1" />
                    Switch to Focus
                  </>
                )}
              </Button>
            </div>
          </CardContent>
          
          <CardFooter className="px-6 py-4 bg-gray-50 dark:bg-slate-800 border-t dark:border-slate-700">
            <div className="flex justify-between items-center w-full">
              <div className="text-sm text-gray-500 dark:text-gray-400">
                Focus: {settings.focusDuration} minutes • Break: {settings.breakDuration} minutes
              </div>
              <Button 
                variant="link" 
                className="text-indigo-600 dark:text-indigo-400 text-sm font-medium p-0"
                onClick={() => window.location.href = '/settings'}
              >
                Customize Times
              </Button>
            </div>
          </CardFooter>
        </Card>
        
        <Card className="mt-6">
          <CardHeader className="border-b dark:border-slate-700 px-6 py-4">
            <CardTitle className="text-lg font-semibold">Focus Session History</CardTitle>
          </CardHeader>
          
          <div className="divide-y dark:divide-slate-700">
            {sessionsByTask.length === 0 ? (
              <div className="px-6 py-8 text-center">
                <p className="text-gray-500 dark:text-gray-400">No focus sessions recorded yet.</p>
                <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
                  Start a timer to track your focus sessions.
                </p>
              </div>
            ) : (
              sessionsByTask.map((session, index) => (
                <div key={index} className="px-6 py-3 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">{session.taskSubject}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {session.lastSession && session.lastSession.startTime 
                        ? new Date(session.lastSession.startTime).toLocaleString(undefined, {
                            weekday: 'short',
                            month: 'short', 
                            day: 'numeric',
                            hour: '2-digit', 
                            minute: '2-digit'
                          })
                        : 'Unknown time'}
                    </p>
                  </div>
                  <div className="text-sm font-medium text-indigo-600 dark:text-indigo-400">
                    {session.sessionCount} {session.sessionCount === 1 ? 'session' : 'sessions'}
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
