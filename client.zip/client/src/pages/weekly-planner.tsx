import { useState, useEffect } from "react";
import { format, addDays, startOfWeek } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, X, Save, Calendar } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// For demonstration, we'll use a static user ID until we implement authentication
const DEMO_USER_ID = 1;

export default function WeeklyPlanner() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [weekDates, setWeekDates] = useState<Date[]>([]);
  const [weeklyTasks, setWeeklyTasks] = useState<Record<string, string[]>>({});
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeDay, setActiveDay] = useState<string | null>(null);
  const [newTask, setNewTask] = useState("");

  // Generate array of dates for the current week
  useEffect(() => {
    const startDate = startOfWeek(currentDate, { weekStartsOn: 1 }); // Start on Monday
    const dates = Array.from({ length: 7 }, (_, i) => addDays(startDate, i));
    setWeekDates(dates);
  }, [currentDate]);

  // Format a date to ISO string (YYYY-MM-DD)
  const formatDateToISO = (date: Date): string => {
    return format(date, "yyyy-MM-dd");
  };

  // Fetch weekly plans for the current week
  const { data: weeklyPlansData, isLoading } = useQuery({
    queryKey: ["/api/weekly-plans", DEMO_USER_ID],
    queryFn: async () => {
      return apiRequest(`/api/weekly-plans/${DEMO_USER_ID}`);
    },
    onSuccess: (data) => {
      if (data) {
        const tasksMap: Record<string, string[]> = {};
        
        // Group tasks by date
        data.forEach((plan: any) => {
          const dateStr = formatDateToISO(new Date(plan.plan_date));
          tasksMap[dateStr] = plan.tasks;
        });
        
        setWeeklyTasks(tasksMap);
      }
    },
  });

  // Create weekly plan mutation
  const createWeeklyPlan = useMutation({
    mutationFn: async ({ date, tasks }: { date: string, tasks: string[] }) => {
      return apiRequest("/api/weekly-plans", {
        method: "POST",
        body: JSON.stringify({
          user_id: DEMO_USER_ID,
          plan_date: date,
          tasks: tasks,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weekly-plans", DEMO_USER_ID] });
      toast({
        title: "Plan saved!",
        description: "Your weekly plan has been updated.",
      });
    },
  });

  // Update weekly plan mutation
  const updateWeeklyPlan = useMutation({
    mutationFn: async ({ planId, tasks }: { planId: number, tasks: string[] }) => {
      return apiRequest(`/api/weekly-plans/${planId}`, {
        method: "PATCH",
        body: JSON.stringify({
          tasks: tasks,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weekly-plans", DEMO_USER_ID] });
      toast({
        title: "Plan updated!",
        description: "Your weekly plan has been updated.",
      });
    },
  });

  // Find the plan ID for a specific date
  const getPlanIdForDate = (date: string): number | null => {
    if (!weeklyPlansData) return null;
    
    const plan = weeklyPlansData.find((p: any) => 
      formatDateToISO(new Date(p.plan_date)) === date
    );
    
    return plan ? plan.id : null;
  };

  // Save tasks for a specific day
  const saveTasks = (date: string, tasks: string[]) => {
    const planId = getPlanIdForDate(date);
    
    if (planId) {
      updateWeeklyPlan.mutate({ planId, tasks });
    } else {
      createWeeklyPlan.mutate({ date, tasks });
    }
  };

  // Open dialog for adding tasks to a specific day
  const openTaskDialog = (date: string) => {
    setActiveDay(date);
    setIsDialogOpen(true);
  };

  // Add a new task to the active day
  const addTask = () => {
    if (!activeDay || !newTask.trim()) return;
    
    const currentTasks = weeklyTasks[activeDay] || [];
    const updatedTasks = [...currentTasks, newTask];
    
    setWeeklyTasks({
      ...weeklyTasks,
      [activeDay]: updatedTasks,
    });
    
    setNewTask("");
  };

  // Remove a task from the active day
  const removeTask = (index: number) => {
    if (!activeDay) return;
    
    const currentTasks = weeklyTasks[activeDay] || [];
    const updatedTasks = currentTasks.filter((_, i) => i !== index);
    
    setWeeklyTasks({
      ...weeklyTasks,
      [activeDay]: updatedTasks,
    });
  };

  // Save tasks for the active day
  const saveActiveDay = () => {
    if (!activeDay) return;
    
    saveTasks(activeDay, weeklyTasks[activeDay] || []);
    setIsDialogOpen(false);
  };

  // Format date for display
  const formatDate = (date: Date): string => {
    return format(date, "EEE, MMM d");
  };

  // Get CSS classes for day card based on task count
  const getDayCardClasses = (date: string): string => {
    const tasks = weeklyTasks[date] || [];
    const baseClasses = "h-full";
    
    if (tasks.length > 0) {
      return `${baseClasses} border-primary/50 bg-primary/5`;
    }
    
    return baseClasses;
  };

  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Weekly Planner</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setCurrentDate(new Date())}
          >
            Today
          </Button>
          <Button
            variant="outline"
            onClick={() => setCurrentDate(addDays(currentDate, -7))}
          >
            Previous Week
          </Button>
          <Button
            variant="outline"
            onClick={() => setCurrentDate(addDays(currentDate, 7))}
          >
            Next Week
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {weekDates.map((date) => {
          const dateStr = formatDateToISO(date);
          const tasks = weeklyTasks[dateStr] || [];
          
          return (
            <Card key={dateStr} className={getDayCardClasses(dateStr)}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{format(date, "EEEE")}</CardTitle>
                <CardDescription>{format(date, "MMMM d, yyyy")}</CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                {isLoading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                ) : tasks.length > 0 ? (
                  <ul className="space-y-1 text-sm">
                    {tasks.map((task, index) => (
                      <li key={index} className="line-clamp-1">{task}</li>
                    ))}
                    {tasks.length > 5 && (
                      <li className="text-xs text-muted-foreground">
                        +{tasks.length - 5} more tasks
                      </li>
                    )}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">No tasks planned</p>
                )}
              </CardContent>
              <CardFooter>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => openTaskDialog(dateStr)}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  {tasks.length > 0 ? "Manage Tasks" : "Add Tasks"}
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>

      {/* Dialog for adding/editing tasks */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {activeDay && format(new Date(activeDay), "EEEE, MMMM d, yyyy")}
            </DialogTitle>
            <DialogDescription>
              Add or remove tasks for this day.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 my-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Enter a new task"
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addTask();
                  }
                }}
              />
              <Button onClick={addTask} size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="border rounded-md">
              {activeDay && weeklyTasks[activeDay] && weeklyTasks[activeDay].length > 0 ? (
                <ul className="divide-y">
                  {weeklyTasks[activeDay].map((task, index) => (
                    <li key={index} className="flex justify-between items-center p-3">
                      <span>{task}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeTask(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="p-4 text-center text-muted-foreground">
                  No tasks added yet
                </div>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={saveActiveDay}>
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}