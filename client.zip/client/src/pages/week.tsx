import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Check } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AddTaskModal } from '@/components/add-task-modal';
import { useTasks } from '@/hooks/use-tasks';
import { useHolidays } from '@/hooks/use-holidays';
import { format, addDays, isSameDay } from 'date-fns';
import { cn, formatRelativeDay } from '@/lib/utils';

export default function Week() {
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  
  const {
    tasks,
    addWeeklyPlan,
    completeTask
  } = useTasks();
  
  const { isHoliday } = useHolidays();
  
  // Generate 7-day array starting from today
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = addDays(new Date(), i);
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayTasks = tasks.filter(task => 
      task.scheduledDate === dateStr && !task.isBacklog
    );
    
    const isHolidayDate = isHoliday(dateStr);
    
    return {
      date,
      dateStr,
      dayOfMonth: format(date, 'd'),
      dayName: format(date, 'EEEE'),
      relativeDay: formatRelativeDay(dateStr),
      isToday: i === 0,
      isHoliday: isHolidayDate,
      tasks: dayTasks,
      completedCount: dayTasks.filter(t => t.completed).length,
      totalCount: dayTasks.length
    };
  });

  return (
    <div className="space-y-6">
      <Card>
        <div className="border-b dark:border-slate-700 px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-semibold">7-Day Rolling Plan</h2>
          <Button onClick={() => setShowAddTaskModal(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Add Week's Tasks
          </Button>
        </div>
        
        <div className="divide-y dark:divide-slate-700">
          {weekDays.map((day) => (
            <div key={day.dateStr} className="px-6 py-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <div className={cn(
                    "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-semibold",
                    day.isToday 
                      ? "bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400" 
                      : "bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400"
                  )}>
                    <span>{day.dayOfMonth}</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-base font-medium">{day.dayName}</p>
                    {day.isHoliday ? (
                      <p className="text-sm text-amber-500 font-medium">Holiday</p>
                    ) : (
                      <p className="text-sm text-gray-500 dark:text-gray-400">{day.relativeDay}</p>
                    )}
                  </div>
                </div>
                <div>
                  {day.tasks.length > 0 ? (
                    day.isToday ? (
                      <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300">
                        {day.completedCount}/{day.totalCount} Done
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300">
                        {day.totalCount} Tasks
                      </Badge>
                    )
                  ) : day.isHoliday ? (
                    <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">
                      Holiday
                    </Badge>
                  ) : null}
                </div>
              </div>
              
              <div className="ml-13 pl-10 space-y-2">
                {day.tasks.length === 0 ? (
                  day.isHoliday ? (
                    <p className="text-sm text-gray-500 dark:text-gray-400">No tasks scheduled for holiday.</p>
                  ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400">No tasks scheduled for this day.</p>
                  )
                ) : (
                  day.tasks.map(task => (
                    <div key={task.id} className="flex items-center">
                      <div className={cn(
                        "w-4 h-4 rounded-full border-2 border-indigo-500",
                        task.completed && "bg-indigo-500"
                      )}>
                        {task.completed && <Check className="h-3 w-3 text-white" />}
                      </div>
                      <span 
                        className={cn(
                          "ml-2 text-gray-700 dark:text-gray-300", 
                          task.completed && "line-through opacity-70"
                        )}
                      >
                        {task.subject}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Add Task Modal */}
      <AddTaskModal
        isOpen={showAddTaskModal}
        onClose={() => setShowAddTaskModal(false)}
        onSubmit={addWeeklyPlan}
      />
    </div>
  );
}
