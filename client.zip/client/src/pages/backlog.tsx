import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TaskItem } from '@/components/task-item';
import { useTasks } from '@/hooks/use-tasks';

export default function Backlog() {
  const {
    getBacklogTasks,
    completeTask,
    deleteTask,
    completeAllBacklogTasks,
    clearCompletedBacklogTasks
  } = useTasks();
  
  const backlogTasks = getBacklogTasks();
  const hasTasks = backlogTasks.length > 0;
  const hasCompletedTasks = backlogTasks.some(task => task.completed);

  return (
    <div className="space-y-6">
      <Card>
        <div className="border-b dark:border-slate-700 px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-semibold">Backlog Tasks</h2>
          <div className="flex space-x-2">
            {hasCompletedTasks && (
              <Button variant="outline" onClick={clearCompletedBacklogTasks}>
                Clear Completed
              </Button>
            )}
            {hasTasks && (
              <Button onClick={completeAllBacklogTasks}>
                Complete All
              </Button>
            )}
          </div>
        </div>
        
        <div className="divide-y dark:divide-slate-700">
          {!hasTasks ? (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500 dark:text-gray-400">No tasks in backlog. Nice work!</p>
            </div>
          ) : (
            backlogTasks.map(task => (
              <TaskItem 
                key={task.id}
                task={task}
                onComplete={completeTask}
                onDelete={deleteTask}
                showDate={true}
              />
            ))
          )}
        </div>
      </Card>
    </div>
  );
}
