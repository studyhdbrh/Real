import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Chart } from '@/components/ui/chart';
import { Download } from 'lucide-react';
import { useTasks } from '@/hooks/use-tasks';
import { useHolidays } from '@/hooks/use-holidays';
import { format, subDays, eachDayOfInterval, parseISO, addMonths, getMonth } from 'date-fns';
import { exportToCSV, downloadCSV } from '@/lib/storage';
import { getSettings } from '@/lib/storage';

type TimeRange = 'week' | 'month' | 'year';

export default function Analytics() {
  const [timeRange, setTimeRange] = useState<TimeRange>('month');
  const { tasks } = useTasks();
  const { holidays } = useHolidays();
  const settings = getSettings();

  // Calculate subject distribution
  const subjectDistribution = useMemo(() => {
    const subjects: Record<string, number> = {};
    
    tasks.forEach(task => {
      if (!subjects[task.subject]) {
        subjects[task.subject] = 0;
      }
      subjects[task.subject] += 1;
    });
    
    return Object.entries(subjects)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [tasks]);

  // Calculate weekly completion
  const weeklyCompletion = useMemo(() => {
    const today = new Date();
    const lastWeek = subDays(today, 6);
    
    const days = eachDayOfInterval({ start: lastWeek, end: today });
    
    return days.map(day => {
      const dateStr = format(day, 'yyyy-MM-dd');
      const dayTasks = tasks.filter(task => task.scheduledDate === dateStr && !task.isBacklog);
      
      const total = dayTasks.length;
      const completed = dayTasks.filter(t => t.completed).length;
      const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
      
      return {
        name: format(day, 'EEE'),
        value: percentage,
      };
    });
  }, [tasks]);

  // Calculate leave usage
  const leaveUsage = useMemo(() => {
    const used = holidays.filter(h => h.used).length;
    const total = settings.monthlyHolidays;
    
    return [
      { name: "Used", value: used },
      { name: "Remaining", value: total - used }
    ];
  }, [holidays, settings.monthlyHolidays]);

  // Calculate monthly performance
  const monthlyPerformance = useMemo(() => {
    const today = new Date();
    const startDate = subDays(today, timeRange === 'week' ? 7 : timeRange === 'month' ? 30 : 365);
    
    const days = eachDayOfInterval({ start: startDate, end: today });
    
    // Group by week or month based on timeRange
    const groupedData: Record<string, {
      tasksCompleted: number;
      tasksMissed: number;
      backlogCompleted: number;
      advancedCompletion: number;
    }> = {};
    
    days.forEach(day => {
      const dateStr = format(day, 'yyyy-MM-dd');
      const groupKey = timeRange === 'week' 
        ? format(day, 'yyyy-MM-dd') 
        : timeRange === 'month' 
          ? format(day, 'yyyy-MM-ww') // Week of year
          : format(day, 'yyyy-MM');   // Month
      
      if (!groupedData[groupKey]) {
        groupedData[groupKey] = {
          tasksCompleted: 0,
          tasksMissed: 0,
          backlogCompleted: 0,
          advancedCompletion: 0
        };
      }
      
      // Count regular task completions
      const dayTasks = tasks.filter(task => task.scheduledDate === dateStr && !task.isBacklog);
      const completedTasks = dayTasks.filter(t => t.completed);
      const missedTasks = dayTasks.filter(t => !t.completed && parseISO(dateStr) < new Date());
      
      // Count backlog completions
      const backlogCompletions = tasks.filter(task => 
        task.isBacklog && 
        task.completed && 
        task.completedAt && 
        format(parseISO(task.completedAt), 'yyyy-MM-dd') === dateStr
      );
      
      // Count advanced completions (tomorrow's tasks completed today)
      const nextDay = format(addMonths(parseISO(dateStr), 1), 'yyyy-MM-dd');
      const advancedCompletions = tasks.filter(task => 
        task.scheduledDate === nextDay && 
        task.completed && 
        task.completedAt && 
        format(parseISO(task.completedAt), 'yyyy-MM-dd') === dateStr
      );
      
      groupedData[groupKey].tasksCompleted += completedTasks.length;
      groupedData[groupKey].tasksMissed += missedTasks.length;
      groupedData[groupKey].backlogCompleted += backlogCompletions.length;
      groupedData[groupKey].advancedCompletion += advancedCompletions.length;
    });
    
    // Convert to array and format for chart
    return Object.entries(groupedData).map(([date, data]) => {
      const displayDate = timeRange === 'week' 
        ? format(parseISO(date), 'EEE') 
        : timeRange === 'month' 
          ? `Week ${date.split('-')[2]}` 
          : format(parseISO(date + '-01'), 'MMM');
          
      return {
        name: displayDate,
        Completed: data.tasksCompleted,
        Missed: data.tasksMissed,
        Backlog: data.backlogCompleted,
        Advanced: data.advancedCompletion
      };
    });
  }, [tasks, timeRange]);

  // Handle data export
  const handleExportData = () => {
    const csvContent = exportToCSV();
    downloadCSV(csvContent, `study-planner-export-${format(new Date(), 'yyyy-MM-dd')}.csv`);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5">
            <CardTitle className="text-lg font-medium mb-3">Weekly Completion</CardTitle>
            <Chart 
              data={weeklyCompletion} 
              type="bar" 
              height={200} 
              nameKey="name"
              valueKey="value"
            />
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-5">
            <CardTitle className="text-lg font-medium mb-3">Subject Distribution</CardTitle>
            <Chart 
              data={subjectDistribution} 
              type="pie" 
              height={200}
              nameKey="name"
              valueKey="value" 
            />
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-5">
            <CardTitle className="text-lg font-medium mb-3">Leaves Used</CardTitle>
            <Chart 
              data={leaveUsage} 
              type="donut" 
              height={200}
              nameKey="name"
              valueKey="value"
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="px-6 py-4 border-b dark:border-slate-700 flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-semibold">Monthly Performance</CardTitle>
          <Button variant="ghost" className="text-indigo-600 dark:text-indigo-400" onClick={handleExportData}>
            <Download className="h-4 w-4 mr-1" />
            Export Data
          </Button>
        </CardHeader>
        
        <CardContent className="p-6">
          <div className="mb-4 flex space-x-2">
            <Button 
              variant={timeRange === 'week' ? 'default' : 'outline'} 
              onClick={() => setTimeRange('week')}
              size="sm"
            >
              Week
            </Button>
            <Button 
              variant={timeRange === 'month' ? 'default' : 'outline'} 
              onClick={() => setTimeRange('month')}
              size="sm"
            >
              Month
            </Button>
            <Button 
              variant={timeRange === 'year' ? 'default' : 'outline'} 
              onClick={() => setTimeRange('year')}
              size="sm"
            >
              Year
            </Button>
          </div>
          
          <div className="h-72">
            <Chart 
              data={monthlyPerformance} 
              type="bar" 
              height={280}
              nameKey="name"
              grid
            />
          </div>
        </CardContent>
        
        <CardFooter className="px-6 py-4 bg-gray-50 dark:bg-slate-800 border-t dark:border-slate-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-indigo-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">Tasks Completed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">Tasks Missed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-amber-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">Backlog Completed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-emerald-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">Advanced Completion</span>
            </div>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
