import React, { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Download, Trash2 } from 'lucide-react';
import { getSettings, saveSettings, downloadCSV, exportToCSV, clearAllData } from '@/lib/storage';
import { Settings } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export default function SettingsPage() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<Settings>(getSettings());
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [areNotificationsEnabled, setAreNotificationsEnabled] = useState(
    Notification.permission === 'granted'
  );
  
  // Handle settings change
  const handleSettingsChange = (key: keyof Settings, value: number | string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  // Toggle dark mode
  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
      handleSettingsChange('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      handleSettingsChange('theme', 'light');
    }
  };

  // Toggle notifications
  const toggleNotifications = async () => {
    if (!areNotificationsEnabled) {
      const permission = await Notification.requestPermission();
      setAreNotificationsEnabled(permission === 'granted');
      
      if (permission === 'granted') {
        toast({
          title: "Notifications enabled",
          description: "You will now receive notifications for your tasks.",
        });
      } else {
        toast({
          title: "Notifications not allowed",
          description: "Please enable notifications in your browser settings.",
          variant: "destructive"
        });
      }
    }
  };

  // Save settings
  const saveChanges = () => {
    saveSettings(settings);
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated.",
    });
  };

  // Export data as CSV
  const handleExportData = () => {
    const csvContent = exportToCSV();
    downloadCSV(csvContent, `study-planner-export-${format(new Date(), 'yyyy-MM-dd')}.csv`);
  };

  // Clear all data
  const handleClearData = () => {
    if (window.confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      clearAllData();
      toast({
        title: "Data cleared",
        description: "All your data has been deleted.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="border-b dark:border-slate-700 px-6 py-4">
          <CardTitle className="text-xl font-semibold">Settings</CardTitle>
        </CardHeader>
        
        <CardContent className="p-6 space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-3">App Preferences</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-base font-medium">Dark Mode</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Toggle between light and dark themes</p>
                </div>
                <Switch 
                  checked={isDarkMode} 
                  onCheckedChange={toggleDarkMode}
                  className="data-[state=checked]:bg-indigo-500"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-base font-medium">Notifications</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Receive reminders for your tasks</p>
                </div>
                <Switch 
                  checked={areNotificationsEnabled} 
                  onCheckedChange={toggleNotifications}
                  className="data-[state=checked]:bg-indigo-500"
                />
              </div>
            </div>
          </div>
          
          <div className="pt-6 border-t dark:border-slate-700">
            <h3 className="text-lg font-medium mb-3">Study Plan Settings</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="monthly-holidays" className="block text-sm font-medium mb-1">Monthly Holiday Allowance</Label>
                <div className="flex items-center">
                  <Input
                    id="monthly-holidays"
                    type="number"
                    value={settings.monthlyHolidays}
                    min={0}
                    max={10}
                    onChange={(e) => handleSettingsChange('monthlyHolidays', parseInt(e.target.value))}
                    className="w-20"
                  />
                  <span className="ml-2 text-gray-500 dark:text-gray-400">days per month</span>
                </div>
              </div>
              
              <div>
                <Label htmlFor="pomodoro-settings" className="block text-sm font-medium mb-1">Pomodoro Timer Settings</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="focus-duration" className="block text-xs text-gray-500 dark:text-gray-400 mb-1">Focus Duration</Label>
                    <div className="flex items-center">
                      <Input
                        id="focus-duration"
                        type="number"
                        value={settings.focusDuration}
                        min={1}
                        max={60}
                        onChange={(e) => handleSettingsChange('focusDuration', parseInt(e.target.value))}
                        className="w-16"
                      />
                      <span className="ml-2 text-gray-500 dark:text-gray-400">minutes</span>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="break-duration" className="block text-xs text-gray-500 dark:text-gray-400 mb-1">Break Duration</Label>
                    <div className="flex items-center">
                      <Input
                        id="break-duration"
                        type="number"
                        value={settings.breakDuration}
                        min={1}
                        max={30}
                        onChange={(e) => handleSettingsChange('breakDuration', parseInt(e.target.value))}
                        className="w-16"
                      />
                      <span className="ml-2 text-gray-500 dark:text-gray-400">minutes</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="pt-6 border-t dark:border-slate-700">
            <h3 className="text-lg font-medium mb-3">Data Management</h3>
            <div className="space-y-4">
              <div>
                <Button
                  variant="outline"
                  className="border-indigo-300 text-indigo-700 dark:border-indigo-700 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20"
                  onClick={handleExportData}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Export All Data (CSV)
                </Button>
              </div>
              
              <div>
                <Button
                  variant="outline"
                  className="border-red-300 text-red-700 dark:border-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                  onClick={handleClearData}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Clear All Data
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="px-6 py-4 bg-gray-50 dark:bg-slate-800 border-t dark:border-slate-700">
          <div className="flex justify-end">
            <Button onClick={saveChanges}>
              Save Changes
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
