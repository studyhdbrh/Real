import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { addDays, format, isAfter, isBefore, isSameDay, parseISO, startOfDay } from "date-fns";
import { v4 as uuidv4 } from "uuid";
import { Task, Holiday } from "./types";

// Utility for combining class names
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format date to display
export function formatDate(date: string | Date): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'EEEE, MMMM d, yyyy');
}

// Format date to short display
export function formatShortDate(date: string | Date): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'EEE, MMM d');
}

// Get today's date as ISO string (without time)
export function getTodayISO(): string {
  return format(new Date(), 'yyyy-MM-dd');
}

// Check if a date is today
export function isToday(date: string | Date): boolean {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isSameDay(dateObj, new Date());
}

// Check if a date is in the past
export function isPast(date: string | Date): boolean {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isBefore(dateObj, startOfDay(new Date()));
}

// Check if a date is in the future
export function isFuture(date: string | Date): boolean {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isAfter(dateObj, startOfDay(new Date()));
}

// Get date n days from today
export function getDatePlusDays(days: number): string {
  return format(addDays(new Date(), days), 'yyyy-MM-dd');
}

// Get days between two dates
export function getDaysBetween(date1: string | Date, date2: string | Date): number {
  const d1 = typeof date1 === 'string' ? parseISO(date1) : date1;
  const d2 = typeof date2 === 'string' ? parseISO(date2) : date2;
  
  const diffInMs = Math.abs(d2.getTime() - d1.getTime());
  return Math.floor(diffInMs / (1000 * 60 * 60 * 24));
}

// Format time (minutes) to MM:SS
export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
  const secs = (seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}

// Generate a unique ID
export function generateId(): string {
  return uuidv4();
}

// Calculate task completion percentage
export function calculateCompletion(completed: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((completed / total) * 100);
}

// Check if a date is marked as holiday
export function isHoliday(date: string, holidays: Holiday[]): boolean {
  return holidays.some(holiday => holiday.date === date);
}

// Get remaining holidays for the current month
export function getRemainingHolidays(holidays: Holiday[], monthlyAllowance: number): number {
  const today = new Date();
  const currentMonth = format(today, 'yyyy-MM');
  
  const usedHolidays = holidays.filter(
    holiday => !holiday.used && holiday.date.startsWith(currentMonth)
  ).length;
  
  return monthlyAllowance - usedHolidays;
}

// Parse task input (Subject: Task Description)
export function parseTaskInput(input: string): { subject: string, description: string } {
  const colonIndex = input.indexOf(':');
  
  if (colonIndex > 0) {
    const subject = input.substring(0, colonIndex).trim();
    const description = input.substring(colonIndex + 1).trim();
    return { subject, description };
  }
  
  return { subject: input, description: '' };
}

// Create a new task
export function createTask(input: string, scheduledDate: string, isBacklog: boolean = false): Task {
  const { subject, description } = parseTaskInput(input);
  
  return {
    id: generateId(),
    subject,
    description,
    scheduledDate,
    completed: false,
    completedAt: undefined,
    isBacklog,
    createdAt: new Date().toISOString()
  };
}

// Format relative day (Today, Tomorrow, etc.)
export function formatRelativeDay(date: string): string {
  const dateObj = parseISO(date);
  const today = startOfDay(new Date());
  const tomorrow = addDays(today, 1);
  
  if (isSameDay(dateObj, today)) {
    return "Today";
  } else if (isSameDay(dateObj, tomorrow)) {
    return "Tomorrow";
  } else {
    const days = getDaysBetween(today, dateObj);
    return `In ${days} days`;
  }
}

// Convert CSV to Blob for download
export function csvToBlob(csvContent: string): Blob {
  return new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
}

// Trigger CSV file download
export function downloadCSV(csvContent: string, filename: string): void {
  const blob = csvToBlob(csvContent);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  
  link.click();
  document.body.removeChild(link);
}

// Request notification permission
export function requestNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) {
    return Promise.resolve(false);
  }
  
  if (Notification.permission === 'granted') {
    return Promise.resolve(true);
  }
  
  if (Notification.permission !== 'denied') {
    return Notification.requestPermission().then(permission => {
      return permission === 'granted';
    });
  }
  
  return Promise.resolve(false);
}

// Show notification
export function showNotification(title: string, options?: NotificationOptions): void {
  if (Notification.permission === 'granted') {
    new Notification(title, options);
  }
}
