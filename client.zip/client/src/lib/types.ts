import { z } from "zod";

// Task schema
export const taskSchema = z.object({
  id: z.string(),
  subject: z.string(),
  description: z.string().optional(),
  scheduledDate: z.string(),
  completed: z.boolean().default(false),
  completedAt: z.string().optional(),
  isBacklog: z.boolean().default(false),
  createdAt: z.string(),
});

export type Task = z.infer<typeof taskSchema>;

// Holiday schema
export const holidaySchema = z.object({
  id: z.string(),
  date: z.string(),
  used: z.boolean().default(false),
  createdAt: z.string(),
});

export type Holiday = z.infer<typeof holidaySchema>;

// Pomodoro session schema
export const pomodoroSessionSchema = z.object({
  id: z.string(),
  taskId: z.string().optional(),
  taskSubject: z.string().optional(),
  startTime: z.string(),
  endTime: z.string().optional(),
  durationMinutes: z.number(),
  isBreak: z.boolean().default(false),
  createdAt: z.string(),
});

export type PomodoroSession = z.infer<typeof pomodoroSessionSchema>;

// Settings schema
export const settingsSchema = z.object({
  monthlyHolidays: z.number().default(7),
  focusDuration: z.number().default(25),
  breakDuration: z.number().default(5),
  theme: z.enum(["light", "dark", "system"]).default("system"),
});

export type Settings = z.infer<typeof settingsSchema>;

// Streak data
export const streakSchema = z.object({
  current: z.number().default(0),
  longest: z.number().default(0),
  lastActiveDate: z.string().optional(),
});

export type Streak = z.infer<typeof streakSchema>;

// Analytics data
export interface WeeklyCompletion {
  day: string;
  completed: number;
  total: number;
  percentage: number;
}

export interface SubjectDistribution {
  subject: string;
  count: number;
  percentage: number;
}

export interface LeaveUsage {
  used: number;
  remaining: number;
  total: number;
}

export interface MonthlyPerformance {
  date: string;
  tasksCompleted: number;
  tasksMissed: number;
  backlogCompleted: number;
  advancedCompletion: number;
}
