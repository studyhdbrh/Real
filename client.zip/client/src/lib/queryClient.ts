import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Interface for request options
interface RequestOptions {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  credentials?: RequestCredentials;
}

/**
 * Helper function to make API requests.
 * 
 * @param url URL or endpoint to make the request to
 * @param options Request options (optional)
 * @returns Promise resolving to JSON response data
 */
export async function apiRequest<T = any>(
  url: string,
  options?: RequestOptions
): Promise<T> {
  // If URL doesn't start with 'http', treat it as a relative path to the API
  const fullUrl = url.startsWith('http') ? url : url;
  
  // Default request options
  const defaultOptions: RequestOptions = {
    method: 'GET',
    headers: {},
    credentials: 'include'
  };
  
  // Merge default options with provided options
  const fetchOptions: RequestOptions = {
    ...defaultOptions,
    ...options
  };

  // Send request
  const res = await fetch(fullUrl, fetchOptions as RequestInit);
  
  // Handle errors
  await throwIfResNotOk(res);
  
  // If the response status is 204 (No Content), return null
  if (res.status === 204) {
    return null as T;
  }
  
  // Parse and return JSON
  return await res.json();
}

// Type definition for unauthorized behavior
type UnauthorizedBehavior = "returnNull" | "throw";

/**
 * Creates a query function for react-query that handles common API request patterns
 */
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null as T;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

/**
 * Configured QueryClient instance for the application
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
