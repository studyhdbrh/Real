import { 
  type Task, 
  type Holiday, 
  type PomodoroSession, 
  type Settings, 
  type Streak,
  settingsSchema
} from "./types";
import { csvToBlob } from './utils';

// Storage keys
const TASKS_KEY = 'study-planner-tasks';
const HOLIDAYS_KEY = 'study-planner-holidays';
const POMODORO_SESSIONS_KEY = 'study-planner-pomodoro-sessions';
const SETTINGS_KEY = 'study-planner-settings';
const STREAK_KEY = 'study-planner-streak';

// Helper to get items from localStorage
function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error(`Error retrieving ${key} from localStorage:`, error);
    return defaultValue;
  }
}

// Helper to set items in localStorage
function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error);
  }
}

// Tasks storage
export function getTasks(): Task[] {
  return getItem<Task[]>(TASKS_KEY, []);
}

export function saveTasks(tasks: Task[]): void {
  setItem<Task[]>(TASKS_KEY, tasks);
}

// Holidays storage
export function getHolidays(): Holiday[] {
  return getItem<Holiday[]>(HOLIDAYS_KEY, []);
}

export function saveHolidays(holidays: Holiday[]): void {
  setItem<Holiday[]>(HOLIDAYS_KEY, holidays);
}

// Pomodoro sessions storage
export function getPomodoroSessions(): PomodoroSession[] {
  return getItem<PomodoroSession[]>(POMODORO_SESSIONS_KEY, []);
}

export function savePomodoroSessions(sessions: PomodoroSession[]): void {
  setItem<PomodoroSession[]>(POMODORO_SESSIONS_KEY, sessions);
}

// Settings storage
export function getSettings(): Settings {
  const defaultSettings: Settings = {
    monthlyHolidays: 7,
    focusDuration: 25,
    breakDuration: 5,
    theme: 'system'
  };
  
  const storedSettings = getItem<Settings>(SETTINGS_KEY, defaultSettings);
  return settingsSchema.parse(storedSettings);
}

export function saveSettings(settings: Settings): void {
  setItem<Settings>(SETTINGS_KEY, settings);
}

// Streak storage
export function getStreak(): Streak {
  const defaultStreak: Streak = {
    current: 0,
    longest: 0,
    lastActiveDate: undefined
  };
  
  return getItem<Streak>(STREAK_KEY, defaultStreak);
}

export function saveStreak(streak: Streak): void {
  setItem<Streak>(STREAK_KEY, streak);
}

// Export data to CSV
export function exportToCSV(): string {
  const tasks = getTasks();
  const headers = ["ID", "Subject", "Description", "Scheduled Date", "Completed", "Completed At", "Backlog", "Created At"];
  
  const rows = tasks.map(task => [
    task.id,
    task.subject,
    task.description || "",
    task.scheduledDate,
    task.completed.toString(),
    task.completedAt || "",
    task.isBacklog.toString(),
    task.createdAt
  ]);
  
  const csvContent = [
    headers.join(","),
    ...rows.map(row => row.join(","))
  ].join("\n");
  
  return csvContent;
}

// Trigger CSV file download
export function downloadCSV(csvContent: string, filename: string): void {
  const blob = csvToBlob(csvContent);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  
  link.click();
  document.body.removeChild(link);
}

// Clear all data
export function clearAllData(): void {
  localStorage.removeItem(TASKS_KEY);
  localStorage.removeItem(HOLIDAYS_KEY);
  localStorage.removeItem(POMODORO_SESSIONS_KEY);
  localStorage.removeItem(STREAK_KEY);
  // Keep settings
}
