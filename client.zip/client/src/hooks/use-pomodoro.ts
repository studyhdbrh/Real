import { useState, useEffect, useCallback } from 'react';
import { getPomodoroSessions, savePomodoroSessions } from '@/lib/storage';
import { PomodoroSession } from '@/lib/types';
import { generateId, showNotification } from '@/lib/utils';

export function usePomodoro(focusDuration: number = 25, breakDuration: number = 5) {
  const [sessions, setSessions] = useState<PomodoroSession[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [timeLeft, setTimeLeft] = useState(focusDuration * 60);
  const [progress, setProgress] = useState(0);
  const [currentSession, setCurrentSession] = useState<PomodoroSession | null>(null);

  // Load pomodoro sessions from local storage
  useEffect(() => {
    const storedSessions = getPomodoroSessions();
    setSessions(storedSessions);
    setLoading(false);
  }, []);

  // Save sessions to local storage when they change
  useEffect(() => {
    if (!loading) {
      savePomodoroSessions(sessions);
    }
  }, [sessions, loading]);

  // Timer effect
  useEffect(() => {
    let timerId: number | undefined;

    if (isRunning && !isPaused) {
      timerId = window.setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            // Timer completed
            clearInterval(timerId);
            
            // Show notification
            const title = mode === 'focus' ? 'Focus session completed!' : 'Break time is over!';
            const body = mode === 'focus' ? 'Take a break now.' : 'Ready to focus again?';
            showNotification(title, { body });
            
            // End current session if it exists
            if (currentSession) {
              endSession();
            }
            
            // Switch mode
            if (mode === 'focus') {
              setMode('break');
              setTimeLeft(breakDuration * 60);
              startBreakSession();
            } else {
              setMode('focus');
              setTimeLeft(focusDuration * 60);
            }
            
            return 0;
          }
          return prev - 1;
        });
        
        // Update progress
        const total = mode === 'focus' ? focusDuration * 60 : breakDuration * 60;
        const elapsed = total - timeLeft + 1;
        setProgress((elapsed / total) * 100);
      }, 1000);
    }

    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isRunning, isPaused, timeLeft, mode, focusDuration, breakDuration, currentSession]);

  // Start timer
  const startTimer = useCallback(() => {
    setIsRunning(true);
    setIsPaused(false);
    
    if (mode === 'focus') {
      startFocusSession();
    } else {
      startBreakSession();
    }
  }, [mode]);

  // Pause timer
  const pauseTimer = useCallback(() => {
    setIsPaused(true);
  }, []);

  // Resume timer
  const resumeTimer = useCallback(() => {
    setIsPaused(false);
  }, []);

  // Reset timer
  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setIsPaused(false);
    setMode('focus');
    setTimeLeft(focusDuration * 60);
    setProgress(0);
    
    if (currentSession) {
      endSession();
    }
  }, [focusDuration, currentSession]);

  // Switch mode
  const switchMode = useCallback(() => {
    if (currentSession) {
      endSession();
    }
    
    if (mode === 'focus') {
      setMode('break');
      setTimeLeft(breakDuration * 60);
    } else {
      setMode('focus');
      setTimeLeft(focusDuration * 60);
    }
    
    setProgress(0);
  }, [mode, focusDuration, breakDuration, currentSession]);

  // Start a focus session
  const startFocusSession = useCallback((taskId?: string, taskSubject?: string) => {
    const session: PomodoroSession = {
      id: generateId(),
      taskId,
      taskSubject,
      startTime: new Date().toISOString(),
      durationMinutes: focusDuration,
      isBreak: false,
      createdAt: new Date().toISOString()
    };
    
    setCurrentSession(session);
  }, [focusDuration]);

  // Start a break session
  const startBreakSession = useCallback(() => {
    const session: PomodoroSession = {
      id: generateId(),
      startTime: new Date().toISOString(),
      durationMinutes: breakDuration,
      isBreak: true,
      createdAt: new Date().toISOString()
    };
    
    setCurrentSession(session);
  }, [breakDuration]);

  // End the current session
  const endSession = useCallback(() => {
    if (!currentSession) return;
    
    const endedSession: PomodoroSession = {
      ...currentSession,
      endTime: new Date().toISOString()
    };
    
    setSessions(prev => [...prev, endedSession]);
    setCurrentSession(null);
  }, [currentSession]);

  // Get recent sessions
  const getRecentSessions = useCallback(() => {
    return [...sessions]
      .filter(s => !s.isBreak)
      .sort((a, b) => 
        new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
      )
      .slice(0, 10);
  }, [sessions]);

  // Group sessions by task
  const getSessionsByTask = useCallback(() => {
    const taskSessions = sessions.filter(s => !s.isBreak && s.taskSubject);
    
    const grouped = taskSessions.reduce((acc, session) => {
      const key = session.taskSubject || 'Unknown';
      
      if (!acc[key]) {
        acc[key] = {
          taskSubject: key,
          sessionCount: 0,
          totalMinutes: 0,
          lastSession: null
        };
      }
      
      acc[key].sessionCount += 1;
      acc[key].totalMinutes += session.durationMinutes;
      
      if (!acc[key].lastSession || new Date(session.startTime) > new Date(acc[key].lastSession.startTime)) {
        acc[key].lastSession = session;
      }
      
      return acc;
    }, {} as Record<string, { 
      taskSubject: string, 
      sessionCount: number, 
      totalMinutes: number,
      lastSession: PomodoroSession | null
    }>);
    
    return Object.values(grouped).sort((a, b) => {
      if (a.lastSession && b.lastSession) {
        return new Date(b.lastSession.startTime).getTime() - new Date(a.lastSession.startTime).getTime();
      }
      return 0;
    });
  }, [sessions]);

  return {
    sessions,
    isRunning,
    isPaused,
    mode,
    timeLeft,
    progress,
    startTimer,
    pauseTimer,
    resumeTimer,
    resetTimer,
    switchMode,
    getRecentSessions,
    getSessionsByTask,
    startFocusSession
  };
}
