import * as React from "react"
import { getStreak } from "@/lib/storage";

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    mql.addEventListener("change", onChange)
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    return () => mql.removeEventListener("change", onChange)
  }, [])

  return !!isMobile
}

// Define streak data interface
export interface StreakData {
  currentStreak: number;
  longestStreak: number;
  lastActive: string | null;
  startDate: string | null;
}

// Export a useStreak hook to track user's study streak
export function useStreak(): StreakData {
  const [streakData, setStreakData] = React.useState<StreakData>({
    currentStreak: 0,
    longestStreak: 0,
    lastActive: null,
    startDate: null
  });
  
  React.useEffect(() => {
    // Get streak data from storage
    const streak = getStreak();
    setStreakData(streak);
  }, []);
  
  return streakData;
}
