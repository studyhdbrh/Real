import { useState, useEffect, useCallback } from 'react';
import { addDays, format, parseISO, startOfDay } from 'date-fns';
import { Task } from '@/lib/types';
import { getTasks, saveTasks } from '@/lib/storage';
import { generateId, getTodayISO } from '@/lib/utils';

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  // Load tasks from local storage
  useEffect(() => {
    const storedTasks = getTasks();
    setTasks(storedTasks);
    setLoading(false);
  }, []);

  // Save tasks to local storage when tasks change
  useEffect(() => {
    if (!loading) {
      saveTasks(tasks);
    }
  }, [tasks, loading]);

  // Get tasks for today
  const getTodayTasks = useCallback(() => {
    const today = getTodayISO();
    return tasks.filter(task => task.scheduledDate === today && !task.isBacklog);
  }, [tasks]);

  // Get 7-day rolling plan tasks
  const getWeekTasks = useCallback(() => {
    const today = new Date();
    const next7Days = Array.from({ length: 7 }, (_, i) => format(addDays(today, i), 'yyyy-MM-dd'));
    return tasks.filter(task => next7Days.includes(task.scheduledDate) && !task.isBacklog);
  }, [tasks]);

  // Get backlog tasks
  const getBacklogTasks = useCallback(() => {
    return tasks.filter(task => task.isBacklog);
  }, [tasks]);

  // Add a new task
  const addTask = useCallback((newTask: Omit<Task, 'id' | 'createdAt'>) => {
    const task: Task = {
      id: generateId(),
      ...newTask,
      createdAt: new Date().toISOString()
    };
    setTasks(prevTasks => [...prevTasks, task]);
    return task;
  }, []);

  // Update an existing task
  const updateTask = useCallback((taskId: string, updates: Partial<Task>) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId ? { ...task, ...updates } : task
      )
    );
  }, []);

  // Delete a task
  const deleteTask = useCallback((taskId: string) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
  }, []);

  // Complete a task
  const completeTask = useCallback((taskId: string) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId 
          ? { ...task, completed: true, completedAt: new Date().toISOString() } 
          : task
      )
    );
  }, []);

  // Move a task to backlog
  const moveToBacklog = useCallback((taskId: string) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId 
          ? { ...task, isBacklog: true } 
          : task
      )
    );
  }, []);

  // Complete all tasks for a specific day
  const completeAllTasksForDay = useCallback((date: string) => {
    const now = new Date().toISOString();
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.scheduledDate === date && !task.completed
          ? { ...task, completed: true, completedAt: now }
          : task
      )
    );
  }, []);

  // Complete all backlog tasks
  const completeAllBacklogTasks = useCallback(() => {
    const now = new Date().toISOString();
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.isBacklog && !task.completed
          ? { ...task, completed: true, completedAt: now }
          : task
      )
    );
  }, []);

  // Clear completed backlog tasks
  const clearCompletedBacklogTasks = useCallback(() => {
    setTasks(prevTasks => 
      prevTasks.filter(task => !(task.isBacklog && task.completed))
    );
  }, []);

  // Add weekly plan of tasks
  const addWeeklyPlan = useCallback((weeklyTasks: { day: number, tasks: string[] }[]) => {
    const today = startOfDay(new Date());
    
    const newTasks = weeklyTasks.flatMap(dayPlan => {
      const scheduledDate = format(addDays(today, dayPlan.day), 'yyyy-MM-dd');
      
      return dayPlan.tasks.map(taskInput => {
        const [subject, description] = taskInput.includes(':') 
          ? [taskInput.split(':')[0].trim(), taskInput.split(':')[1].trim()]
          : [taskInput, ''];
          
        return {
          id: generateId(),
          subject,
          description,
          scheduledDate,
          completed: false,
          isBacklog: false,
          createdAt: new Date().toISOString()
        };
      });
    });
    
    setTasks(prevTasks => [...prevTasks, ...newTasks]);
  }, []);

  // Work ahead (complete tomorrow's task today)
  const workAhead = useCallback((taskId: string) => {
    const today = parseISO(getTodayISO());
    const tomorrow = format(addDays(today, 1), 'yyyy-MM-dd');
    
    setTasks(prevTasks => {
      // Find the task to work ahead
      const tomorrowTask = prevTasks.find(task => task.id === taskId);
      
      if (!tomorrowTask || tomorrowTask.scheduledDate !== tomorrow) {
        return prevTasks;
      }
      
      return prevTasks.map(task => 
        task.id === taskId 
          ? { ...task, completed: true, completedAt: new Date().toISOString() } 
          : task
      );
    });
  }, []);

  // Calculate task completion statistics
  const getTaskStats = useCallback(() => {
    const todayTasks = getTodayTasks();
    const weekTasks = getWeekTasks();
    const backlogTasks = getBacklogTasks();
    
    const today = {
      total: todayTasks.length,
      completed: todayTasks.filter(t => t.completed).length,
      percentage: todayTasks.length > 0 
        ? Math.round((todayTasks.filter(t => t.completed).length / todayTasks.length) * 100)
        : 0
    };
    
    const week = {
      total: weekTasks.length,
      completed: weekTasks.filter(t => t.completed).length,
      percentage: weekTasks.length > 0 
        ? Math.round((weekTasks.filter(t => t.completed).length / weekTasks.length) * 100)
        : 0
    };
    
    const backlog = {
      total: backlogTasks.length,
      completed: backlogTasks.filter(t => t.completed).length,
      pending: backlogTasks.filter(t => !t.completed).length
    };
    
    return { today, week, backlog };
  }, [getTodayTasks, getWeekTasks, getBacklogTasks]);

  return {
    tasks,
    loading,
    getTodayTasks,
    getWeekTasks,
    getBacklogTasks,
    addTask,
    updateTask,
    deleteTask,
    completeTask,
    moveToBacklog,
    completeAllTasksForDay,
    completeAllBacklogTasks,
    clearCompletedBacklogTasks,
    addWeeklyPlan,
    workAhead,
    getTaskStats
  };
}
