import { useState, useEffect, useCallback } from 'react';
import { format, parseISO, isSameMonth } from 'date-fns';
import { getHolidays, saveHolidays } from '@/lib/storage';
import { Holiday } from '@/lib/types';
import { generateId } from '@/lib/utils';

export function useHolidays() {
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [loading, setLoading] = useState(true);

  // Load holidays from local storage
  useEffect(() => {
    const storedHolidays = getHolidays();
    setHolidays(storedHolidays);
    setLoading(false);
  }, []);

  // Save holidays to local storage when holidays change
  useEffect(() => {
    if (!loading) {
      saveHolidays(holidays);
    }
  }, [holidays, loading]);

  // Add a new holiday
  const addHoliday = useCallback((date: string) => {
    const newHoliday: Holiday = {
      id: generateId(),
      date,
      used: false,
      createdAt: new Date().toISOString()
    };

    setHolidays(prevHolidays => {
      // Check if holiday already exists for this date
      const exists = prevHolidays.some(h => h.date === date);
      if (exists) return prevHolidays;
      
      return [...prevHolidays, newHoliday];
    });
  }, []);

  // Remove a holiday
  const removeHoliday = useCallback((holidayId: string) => {
    setHolidays(prevHolidays => prevHolidays.filter(h => h.id !== holidayId));
  }, []);

  // Use a holiday (mark as used)
  const useHoliday = useCallback((holidayId: string) => {
    setHolidays(prevHolidays => 
      prevHolidays.map(h => 
        h.id === holidayId ? { ...h, used: true } : h
      )
    );
  }, []);

  // Save a holiday when studying on a holiday
  const saveHolidayAsLeave = useCallback((date: string) => {
    setHolidays(prevHolidays => {
      // Find if this date is a holiday
      const existingHoliday = prevHolidays.find(h => h.date === date);
      
      if (!existingHoliday) return prevHolidays;
      
      // Create a new saved leave with the same date but marked as used=false
      // This effectively gives an extra leave that can be used later
      const savedLeave: Holiday = {
        id: generateId(),
        date: existingHoliday.date,
        used: false,
        createdAt: new Date().toISOString()
      };
      
      // Mark the original holiday as used
      return prevHolidays.map(h => 
        h.id === existingHoliday.id ? { ...h, used: true } : h
      ).concat(savedLeave);
    });
  }, []);

  // Get upcoming holidays
  const getUpcomingHolidays = useCallback(() => {
    const today = new Date();
    const todayIso = format(today, 'yyyy-MM-dd');
    
    return holidays
      .filter(h => h.date >= todayIso && !h.used)
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [holidays]);

  // Check if a date is a holiday
  const isHoliday = useCallback((date: string) => {
    return holidays.some(h => h.date === date && !h.used);
  }, [holidays]);

  // Get holidays for the current month
  const getCurrentMonthHolidays = useCallback(() => {
    const today = new Date();
    
    return holidays.filter(h => {
      const holidayDate = parseISO(h.date);
      return isSameMonth(holidayDate, today);
    });
  }, [holidays]);

  // Get remaining holidays for the current month
  const getRemainingHolidays = useCallback((monthlyAllowance: number) => {
    const currentMonthHolidays = getCurrentMonthHolidays();
    const usedHolidays = currentMonthHolidays.filter(h => h.used).length;
    
    return monthlyAllowance - usedHolidays;
  }, [getCurrentMonthHolidays]);

  return {
    holidays,
    loading,
    addHoliday,
    removeHoliday,
    useHoliday,
    saveHolidayAsLeave,
    getUpcomingHolidays,
    isHoliday,
    getCurrentMonthHolidays,
    getRemainingHolidays
  };
}
