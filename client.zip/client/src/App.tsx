import React, { useState, useEffect } from 'react';
import { Switch, Route, useLocation } from 'wouter';
import { Toaster } from "@/components/ui/toaster";
import { Sidebar } from "@/components/ui/sidebar";
import { AddTaskModal } from "@/components/add-task-modal";
import { Button } from "@/components/ui/button";
import NotFound from "@/pages/not-found";
import Today from "@/pages/today";
import Week from "@/pages/week";
import Backlog from "@/pages/backlog";
import Analytics from "@/pages/analytics";
import Pomodoro from "@/pages/pomodoro";
import Settings from "@/pages/settings";
import Profile from "@/pages/profile";
import WeeklyPlanner from "@/pages/weekly-planner";
import { Plus } from "lucide-react";
import { useStreak } from "@/hooks/use-mobile";
import { getSettings, saveSettings } from "@/lib/storage";
import { format } from "date-fns";
import { Badge } from "./components/ui/badge";
import { useTasks } from "./hooks/use-tasks";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// For demonstration, we'll use a static user ID until we implement authentication
const DEMO_USER_ID = 1;

function App() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [darkMode, setDarkMode] = useState(() => {
    const settings = getSettings();
    return settings.theme === 'dark' || (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const streak = useStreak();
  const { addWeeklyPlan } = useTasks();

  // Fetch user profile
  const { data: profile } = useQuery({
    queryKey: ['/api/profiles', DEMO_USER_ID],
    queryFn: async () => {
      try {
        const response = await apiRequest<any>(`/api/profiles/${DEMO_USER_ID}`);
        return response || null;
      } catch (error) {
        // If profile doesn't exist yet, return null
        return null;
      }
    }
  });

  // Set dark mode based on user preference
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Toggle dark mode
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    const settings = getSettings();
    settings.theme = !darkMode ? 'dark' : 'light';
    saveSettings(settings);
    
    // Also update theme in database if settings exist
    updateDatabaseSettings(settings.theme);
  };
  
  // Update settings in database
  const updateDatabaseSettings = async (theme: string) => {
    try {
      // First check if settings exist for this user
      const response = await apiRequest<any>(`/api/settings/${DEMO_USER_ID}`);
      
      if (response && response.id) {
        // Update existing settings
        await apiRequest(`/api/settings/${response.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ theme })
        });
      } else {
        // Create new settings
        await apiRequest('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            user_id: DEMO_USER_ID,
            theme,
            monthly_holidays: 7,
            focus_duration: 25,
            break_duration: 5
          })
        });
      }
    } catch (error) {
      // Silently fail - we'll keep the setting in local storage anyway
      console.error('Failed to update theme in database', error);
    }
  };

  // Calculate current view from URL
  const getCurrentView = () => {
    const path = location.split('/')[1];
    return path || 'today';
  };

  // Set page title based on current view
  useEffect(() => {
    const view = getCurrentView();
    const titles: Record<string, string> = {
      'today': "Today's Tasks",
      'week': '7-Day Plan',
      'weekly-planner': 'Weekly Planner',
      'backlog': 'Backlog Tasks',
      'analytics': 'Analytics & Stats',
      'pomodoro': 'Pomodoro Timer',
      'profile': 'User Profile',
      'settings': 'Settings'
    };
    
    document.title = `StudyPlanner - ${titles[view] || 'Study Planner'}`;
  }, [location]);

  // Get display name for avatar
  const getDisplayName = (): string => {
    if (profile && profile.display_name) return profile.display_name;
    return "User";
  };

  // Get initials for avatar fallback
  const getInitials = (): string => {
    const name = getDisplayName();
    return name.split(" ")
      .map((n: string) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50 text-gray-900 dark:bg-slate-900 dark:text-gray-100">
      <Sidebar
        currentView={getCurrentView()}
        onViewChange={(view) => navigate(`/${view}`)}
        darkMode={darkMode}
        toggleDarkMode={toggleDarkMode}
      />

      <div className="flex-1 overflow-auto">
        {/* Top header with mobile menu button and page title */}
        <header className="bg-white dark:bg-slate-900 shadow-sm">
          <div className="px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <div className="flex-1 flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
                  {getCurrentView() === 'today' ? 'Today\'s Tasks' : 
                   getCurrentView() === 'week' ? '7-Day Plan' : 
                   getCurrentView() === 'weekly-planner' ? 'Weekly Planner' : 
                   getCurrentView() === 'backlog' ? 'Backlog Tasks' : 
                   getCurrentView() === 'analytics' ? 'Analytics & Stats' :
                   getCurrentView() === 'pomodoro' ? 'Pomodoro Timer' :
                   getCurrentView() === 'profile' ? 'User Profile' :
                   'Settings'}
                </h1>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  {format(new Date(), 'EEEE, MMMM d, yyyy')}
                </p>
              </div>
              <div className="ml-4 flex items-center md:ml-6 space-x-3">
                <Badge className="bg-gray-100 dark:bg-slate-800 pl-3 pr-4 py-2 rounded-full flex items-center text-sm">
                  <span className="text-emerald-500 mr-2">⚡</span>
                  <span>Streak: {streak?.currentStreak || 0} days</span>
                </Badge>
                <Button onClick={() => setShowAddTaskModal(true)}>
                  <Plus className="h-4 w-4 mr-1" />
                  <span>Add Task</span>
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="p-1 rounded-full" 
                  onClick={() => navigate('/profile')}
                >
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {getInitials()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Main content container */}
        <main className="p-4 sm:p-6 lg:p-8">
          <Switch>
            <Route path="/" component={Today} />
            <Route path="/today" component={Today} />
            <Route path="/week" component={Week} />
            <Route path="/weekly-planner" component={WeeklyPlanner} />
            <Route path="/backlog" component={Backlog} />
            <Route path="/analytics" component={Analytics} />
            <Route path="/pomodoro" component={Pomodoro} />
            <Route path="/profile" component={Profile} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>

      {/* Add Task Modal */}
      <AddTaskModal
        isOpen={showAddTaskModal}
        onClose={() => setShowAddTaskModal(false)}
        onSubmit={addWeeklyPlan}
      />

      <Toaster />
    </div>
  );
}

export default App;
