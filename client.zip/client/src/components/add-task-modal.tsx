import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { format, addDays } from 'date-fns';

interface Day {
  date: Date;
  formattedDate: string;
  tasks: string[];
}

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (weeklyTasks: { day: number, tasks: string[] }[]) => void;
}

export function AddTaskModal({ isOpen, onClose, onSubmit }: AddTaskModalProps) {
  const [expandedDays, setExpandedDays] = useState(1);
  
  // Initialize 7 days with today as the first day
  const [days, setDays] = useState<Day[]>(() => {
    const today = new Date();
    return Array.from({ length: 7 }, (_, i) => {
      const date = addDays(today, i);
      return {
        date,
        formattedDate: format(date, "EEEE, MMMM d"),
        tasks: i === 0 ? [''] : [] // Start with one empty task for day 1
      };
    });
  });

  // Add a new task to a specific day
  const addTaskToDay = (dayIndex: number) => {
    setDays(prevDays => {
      const newDays = [...prevDays];
      newDays[dayIndex].tasks.push('');
      return newDays;
    });
  };

  // Update a task for a specific day
  const updateTask = (dayIndex: number, taskIndex: number, value: string) => {
    setDays(prevDays => {
      const newDays = [...prevDays];
      newDays[dayIndex].tasks[taskIndex] = value;
      return newDays;
    });
  };

  // Show more days
  const showMoreDays = () => {
    setExpandedDays(prev => Math.min(prev + 2, 7));
  };

  // Handle form submission
  const handleSubmit = () => {
    const weeklyTasks = days
      .slice(0, expandedDays)
      .map((day, index) => ({
        day: index,
        tasks: day.tasks.filter(task => task.trim() !== '')
      }))
      .filter(dayData => dayData.tasks.length > 0);
    
    onSubmit(weeklyTasks);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={isOpen => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Weekly Tasks</DialogTitle>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
            Enter your tasks for the next 7 days. Each day can have multiple subjects.
          </p>
        </DialogHeader>
        
        <div className="mt-4 space-y-4 max-h-[60vh] overflow-y-auto px-1">
          {days.slice(0, expandedDays).map((day, dayIndex) => (
            <div key={dayIndex} className="border dark:border-slate-700 rounded-md p-4">
              <h4 className="font-medium mb-2">Day {dayIndex + 1}: {day.formattedDate}</h4>
              <div className="space-y-2">
                {day.tasks.map((task, taskIndex) => (
                  <div key={taskIndex}>
                    <Input
                      placeholder="Subject: Task Description"
                      value={task}
                      onChange={(e) => updateTask(dayIndex, taskIndex, e.target.value)}
                      className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 dark:border-slate-600 dark:bg-slate-800 dark:text-white rounded-md"
                    />
                  </div>
                ))}
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 px-0"
                  onClick={() => addTaskToDay(dayIndex)}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add another task
                </Button>
              </div>
            </div>
          ))}
          
          {expandedDays < 7 && (
            <Button
              variant="ghost"
              className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700"
              onClick={showMoreDays}
            >
              Show more days
            </Button>
          )}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            Save Tasks
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
