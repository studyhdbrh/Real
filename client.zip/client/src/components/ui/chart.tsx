import React from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
} from 'recharts';
import { cn } from '@/lib/utils';

export interface ChartProps {
  data: any[];
  type: 'pie' | 'bar' | 'line' | 'donut';
  className?: string;
  height?: number;
  width?: number;
  dataKey?: string;
  nameKey?: string;
  valueKey?: string;
  colors?: string[];
  legend?: boolean;
  tooltip?: boolean;
  grid?: boolean;
  xAxis?: string;
  yAxis?: string;
}

export function Chart({
  data,
  type,
  className,
  height = 300,
  width = 400,
  dataKey = 'name',
  nameKey = 'name',
  valueKey = 'value',
  colors = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
  legend = true,
  tooltip = true,
  grid = false,
  xAxis,
  yAxis,
}: ChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className={cn("flex items-center justify-center h-full", className)}>
        <p className="text-gray-400">No data available</p>
      </div>
    );
  }

  const renderChart = () => {
    switch (type) {
      case 'pie':
      case 'donut':
        return (
          <PieChart width={width} height={height}>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              nameKey={nameKey}
              dataKey={valueKey}
              innerRadius={type === 'donut' ? '50%' : 0}
              outerRadius={type === 'donut' ? '70%' : '80%'}
              fill="#8884d8"
              paddingAngle={type === 'donut' ? 5 : 0}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            >
              {data.map((_, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Pie>
            {legend && <Legend />}
            {tooltip && <Tooltip />}
          </PieChart>
        );
      case 'bar':
        return (
          <BarChart width={width} height={height} data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            {grid && <CartesianGrid strokeDasharray="3 3" />}
            <XAxis dataKey={dataKey} tick={{fontSize: 12}} />
            <YAxis tick={{fontSize: 12}} />
            {tooltip && <Tooltip />}
            {legend && <Legend />}
            <Bar dataKey={valueKey} fill={colors[0]} />
          </BarChart>
        );
      case 'line':
        return (
          <LineChart width={width} height={height} data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            {grid && <CartesianGrid strokeDasharray="3 3" />}
            <XAxis dataKey={dataKey} tick={{fontSize: 12}} />
            <YAxis tick={{fontSize: 12}} />
            {tooltip && <Tooltip />}
            {legend && <Legend />}
            <Line type="monotone" dataKey={valueKey} stroke={colors[0]} strokeWidth={2} />
            {xAxis && <Line type="monotone" dataKey={xAxis} stroke={colors[1]} strokeWidth={2} />}
            {yAxis && <Line type="monotone" dataKey={yAxis} stroke={colors[2]} strokeWidth={2} />}
          </LineChart>
        );
      default:
        return null;
    }
  };

  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width="100%" height={height}>
        {renderChart()}
      </ResponsiveContainer>
    </div>
  );
}
