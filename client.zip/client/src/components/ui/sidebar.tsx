import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  BookOpen,
  Calendar,
  ClipboardList,
  BarChart2,
  Timer,
  Settings,
  Moon,
  Sun,
  Menu,
  X,
  User,
  CalendarDays
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

export function Sidebar({ currentView, onViewChange, darkMode, toggleDarkMode }: SidebarProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Set sidebar open by default on large screens
  useEffect(() => {
    const handleResize = () => {
      setSidebarOpen(window.innerWidth >= 1024);
    };
    
    handleResize();
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const closeSidebar = () => {
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden absolute top-4 left-4 z-50"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        <Menu className="h-6 w-6" />
      </Button>

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-slate-900 shadow-md transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo and brand */}
          <div className="flex items-center justify-between px-4 py-5 border-b dark:border-slate-700">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-6 w-6 text-indigo-500" />
              <span className="text-xl font-semibold">StudyPlanner</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Navigation links */}
          <nav className="flex-1 px-2 py-4 space-y-2 overflow-y-auto">
            <div className="text-xs uppercase text-gray-500 dark:text-gray-400 px-3 mb-1">
              Planning
            </div>
            
            <Button
              variant={currentView === 'today' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'today' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('today');
                closeSidebar();
              }}
            >
              <Calendar className="mr-3 h-5 w-5" />
              Today's Tasks
            </Button>
            
            <Button
              variant={currentView === 'week' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'week' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('week');
                closeSidebar();
              }}
            >
              <Calendar className="mr-3 h-5 w-5" />
              7-Day Plan
            </Button>
            
            <Button
              variant={currentView === 'weekly-planner' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'weekly-planner' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('weekly-planner');
                closeSidebar();
              }}
            >
              <CalendarDays className="mr-3 h-5 w-5" />
              Weekly Planner
            </Button>
            
            <Button
              variant={currentView === 'backlog' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'backlog' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('backlog');
                closeSidebar();
              }}
            >
              <ClipboardList className="mr-3 h-5 w-5" />
              Backlog
            </Button>
            
            <Separator className="my-2" />
            
            <div className="text-xs uppercase text-gray-500 dark:text-gray-400 px-3 mb-1">
              Tools
            </div>
            
            <Button
              variant={currentView === 'pomodoro' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'pomodoro' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('pomodoro');
                closeSidebar();
              }}
            >
              <Timer className="mr-3 h-5 w-5" />
              Pomodoro Timer
            </Button>
            
            <Button
              variant={currentView === 'analytics' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'analytics' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('analytics');
                closeSidebar();
              }}
            >
              <BarChart2 className="mr-3 h-5 w-5" />
              Analytics
            </Button>
            
            <Separator className="my-2" />
            
            <div className="text-xs uppercase text-gray-500 dark:text-gray-400 px-3 mb-1">
              Account
            </div>
            
            <Button
              variant={currentView === 'profile' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'profile' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('profile');
                closeSidebar();
              }}
            >
              <User className="mr-3 h-5 w-5" />
              Profile
            </Button>
            
            <Button
              variant={currentView === 'settings' ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                currentView === 'settings' 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800"
              )}
              onClick={() => {
                onViewChange('settings');
                closeSidebar();
              }}
            >
              <Settings className="mr-3 h-5 w-5" />
              Settings
            </Button>
          </nav>

          {/* User info and theme toggle */}
          <div className="p-4 border-t dark:border-slate-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="text-sm">
                  <p className="font-medium">Database Sync</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Your data is synced</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={toggleDarkMode}
                className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800"
              >
                {darkMode ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
