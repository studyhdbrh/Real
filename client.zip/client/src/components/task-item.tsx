import React from 'react';
import { Check, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn, formatDate } from '@/lib/utils';
import { Task } from '@/lib/types';
import { Badge } from '@/components/ui/badge';

interface TaskItemProps {
  task: Task;
  onComplete: (taskId: string) => void;
  onEdit?: (task: Task) => void;
  onDelete?: (taskId: string) => void;
  showDate?: boolean;
}

export function TaskItem({ task, onComplete, onEdit, onDelete, showDate = false }: TaskItemProps) {
  return (
    <div className="px-6 py-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
      <div className="flex-1 pr-4">
        <div className="flex items-start">
          <div className="flex-shrink-0 pt-1">
            {!task.completed ? (
              <button 
                className="w-5 h-5 rounded-full border-2 border-indigo-500 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                onClick={() => onComplete(task.id)}
              >
                <span className="hidden material-icons text-indigo-500 text-xs">
                  <Check className="h-3 w-3" />
                </span>
              </button>
            ) : (
              <div className="w-5 h-5 rounded-full border-2 border-indigo-500 bg-indigo-500 flex items-center justify-center">
                <Check className="h-3 w-3 text-white" />
              </div>
            )}
          </div>
          <div className="ml-3">
            <p className={cn("text-base font-medium text-gray-900 dark:text-white", 
              task.completed && "line-through opacity-70")}>
              {task.subject}
            </p>
            {task.description && (
              <p className={cn("text-sm text-gray-500 dark:text-gray-400", 
                task.completed && "line-through opacity-70")}>
                {task.description}
              </p>
            )}
            {showDate && (
              <div className="mt-1">
                {task.isBacklog ? (
                  <Badge variant="destructive" className="text-xs">
                    From {formatDate(task.scheduledDate)}
                  </Badge>
                ) : (
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    Scheduled for {formatDate(task.scheduledDate)}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        {task.completed ? (
          <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300">
            Completed
          </Badge>
        ) : (
          <>
            {onEdit && (
              <Button variant="ghost" size="icon" onClick={() => onEdit(task)}>
                <Edit className="h-4 w-4 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300" />
              </Button>
            )}
            {onDelete && (
              <Button variant="ghost" size="icon" onClick={() => onDelete(task.id)}>
                <Trash2 className="h-4 w-4 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300" />
              </Button>
            )}
            <Button 
              size="icon"
              className="p-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-full text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30"
              onClick={() => onComplete(task.id)}
            >
              <Check className="h-4 w-4" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
