import React, { useState } from 'react';
import { Info, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { formatDate } from '@/lib/utils';
import { Holiday } from '@/lib/types';

interface HolidayModalProps {
  isOpen: boolean;
  onClose: () => void;
  holidays: Holiday[];
  remainingHolidays: number;
  monthlyAllowance: number;
  onAddHoliday: (date: string) => void;
  onRemoveHoliday: (id: string) => void;
}

export function HolidayModal({
  isOpen,
  onClose,
  holidays,
  remainingHolidays,
  monthlyAllowance,
  onAddHoliday,
  onRemoveHoliday
}: HolidayModalProps) {
  const [newHolidayDate, setNewHolidayDate] = useState('');

  const handleAddHoliday = () => {
    if (newHolidayDate) {
      onAddHoliday(newHolidayDate);
      setNewHolidayDate('');
    }
  };

  // Sort and filter holidays - show only upcoming and unused
  const upcomingHolidays = holidays
    .filter(holiday => !holiday.used && new Date(holiday.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <Dialog open={isOpen} onOpenChange={isOpen => !isOpen && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Manage Holidays</DialogTitle>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
            You have {remainingHolidays} holidays remaining this month out of {monthlyAllowance} total.
          </p>
        </DialogHeader>
        
        <div className="mt-4">
          <Alert className="bg-amber-50 dark:bg-amber-900/20 rounded-md mb-4">
            <Info className="h-4 w-4 text-amber-500" />
            <AlertDescription className="text-amber-700 dark:text-amber-300">
              If you study on a holiday, that holiday is saved as an extra leave you can use later.
            </AlertDescription>
          </Alert>
          
          <div className="space-y-3">
            <div className="font-medium mb-2">Upcoming Holidays</div>
            
            {upcomingHolidays.length === 0 ? (
              <p className="text-sm text-gray-500 dark:text-gray-400">No upcoming holidays scheduled.</p>
            ) : (
              upcomingHolidays.map(holiday => (
                <div key={holiday.id} className="flex items-center justify-between p-3 border dark:border-slate-700 rounded-md">
                  <div>
                    <div className="font-medium">{formatDate(holiday.date)}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {Math.ceil((new Date(holiday.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days from now
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300"
                    onClick={() => onRemoveHoliday(holiday.id)}
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </div>
              ))
            )}
          </div>
          
          <div className="mt-5">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Add New Holiday
            </label>
            <div className="flex space-x-2">
              <Input
                type="date"
                value={newHolidayDate}
                onChange={(e) => setNewHolidayDate(e.target.value)}
                className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 dark:border-slate-600 dark:bg-slate-800 dark:text-white rounded-md"
              />
              <Button onClick={handleAddHoliday}>
                Add
              </Button>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
